package com.example.youssefsaibi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoussefsaibiApplicationTests {

	@Test
	void contextLoads() {
	}

}
