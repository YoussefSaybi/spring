package com.example.youssefsaibi.Service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GpsService {

    private final String NOMINATIM_SEARCH_URL = "https://nominatim.openstreetmap.org/search?format=json&q={address}";
    private final String NOMINATIM_REVERSE_URL = "https://nominatim.openstreetmap.org/reverse?format=json&lat={lat}&lon={lon}";

    private final RestTemplate restTemplate = new RestTemplate();

    // Forward Geocoding: Address to Coordinates
    public String getCoordinatesFromAddress(String address) {
        try {
            String response = restTemplate.getForObject(NOMINATIM_SEARCH_URL, String.class, address);
            JSONArray results = new JSONArray(response);
            if (results.length() > 0) {
                JSONObject location = results.getJSONObject(0);
                String lat = location.getString("lat");
                String lon = location.getString("lon");
                return "Latitude: " + lat + ", Longitude: " + lon;
            }
            return "No results found for the given address.";
        } catch (Exception e) {
            return "Error retrieving coordinates: " + e.getMessage();
        }
    }

    // Reverse Geocoding: Coordinates to Address
    public String getAddressFromCoordinates(double latitude, double longitude) {
        try {
            String response = restTemplate.getForObject(NOMINATIM_REVERSE_URL, String.class, latitude, longitude);
            JSONObject result = new JSONObject(response);
            return result.optString("display_name", "No address found for the given coordinates.");
        } catch (Exception e) {
            return "Error retrieving address: " + e.getMessage();
        }
    }

    // Simulate a dynamic GPS location (Example: User's live location)
    public String getCurrentLocation() {
        // Example dynamic GPS location (use actual GPS hardware integration in a real system)
        double latitude = 48.8566; // Paris latitude
        double longitude = 2.3522; // Paris longitude

        // Get the address from the simulated coordinates
        return getAddressFromCoordinates(latitude, longitude);
    }
}
