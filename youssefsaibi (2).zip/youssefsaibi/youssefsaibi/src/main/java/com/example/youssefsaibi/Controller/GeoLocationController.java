package com.example.youssefsaibi.Controller;

import com.example.youssefsaibi.Service.GeoLocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

public class GeoLocationController {
    @Autowired
    private GeoLocationService geoLocationService;

    @GetMapping("/reverse-geocode")
    public String reverseGeocode(double latitude, double longitude) {
        return geoLocationService.getLocationByCoordinates(latitude, longitude);
    }
}
