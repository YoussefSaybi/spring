//package com.example.youssefsaibi.Config;
//
//import org.springframework.amqp.core.Queue;
//import org.springframework.amqp.core.TopicExchange;
//import org.springframework.amqp.core.Binding;
//import org.springframework.amqp.core.BindingBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class RabbitConfig {
//
//    // Define the queue
//    @Bean
//    public Queue candidatQueue() {
//        return new Queue("candidatQueue", true);  // Durable queue
//    }
//
//    // Define the exchange
//    @Bean
//    public TopicExchange candidatExchange() {
//        return new TopicExchange("candidatExchange");
//    }
//
//    // Define the binding between the queue and the exchange
//    @Bean
//    public Binding binding(Queue candidatQueue, TopicExchange candidatExchange) {
//        return BindingBuilder.bind(candidatQueue).to(candidatExchange).with("candidat.#");
//    }
//}
