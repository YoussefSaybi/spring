package com.example.youssefsaibi.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;



import com.example.youssefsaibi.Entity.Candidat;
import com.example.youssefsaibi.Repository.CandidatRepository;


@Service
public class CandidatService {

    @Autowired
    private CandidatRepository candidatRepository;

    public List<Candidat> getAllCandidats() {
        return candidatRepository.findAll();
    }

    public Optional<Candidat> getCandidatById(Long id) {
        return candidatRepository.findById(id);
    }

    public Candidat saveCandidat(Candidat candidat) {
        return candidatRepository.save(candidat);
    }

    public Candidat updateCandidat(Long id, Candidat candidat) {
        return candidatRepository.findById(id)
                .map(existingCandidat -> {
                    existingCandidat.setNom(candidat.getNom());
                    existingCandidat.setPrenom(candidat.getPrenom());
                    existingCandidat.setEmail(candidat.getEmail());
                    existingCandidat.setCvUrl(candidat.getCvUrl());
                    return candidatRepository.save(existingCandidat);
                })
                .orElse(null);
    }

    public void deleteCandidat(Long id) {
        candidatRepository.deleteById(id);
    }
}
