package com.example.youssefsaibi.Service;

import org.springframework.stereotype.Service;

@Service
public class MessagingService {

    // Simple method to simulate sending a message
    public void sendMessage(String message) {
        // Here, we will just log the message to the console
        System.out.println("Message: " + message);
    }
}
