package com.example.youssefsaibi.Repository;

import com.example.youssefsaibi.Entity.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConversationRepository extends JpaRepository<Conversation, Long> {
}
