package com.example.youssefsaibi.Service;

import com.example.youssefsaibi.Entity.Admin;
import com.example.youssefsaibi.Entity.Candidat;
import com.example.youssefsaibi.Entity.Conversation;
import com.example.youssefsaibi.Entity.Message;
import com.example.youssefsaibi.Repository.AdminRepository;
import com.example.youssefsaibi.Repository.CandidatRepository;
import com.example.youssefsaibi.Repository.ConversationRepository;
import com.example.youssefsaibi.Repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MessageService {

    @Autowired
    private ConversationRepository conversationRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private CandidatRepository candidatRepository;

    @Autowired
    private AdminRepository adminRepository;

    // Créer une conversation entre un candidat et un admin
    public Conversation createConversation(Long candidatId, Long adminId) {
        Candidat candidat = candidatRepository.findById(candidatId).orElseThrow(() -> new RuntimeException("Candidat not found"));
        Admin admin = adminRepository.findById(adminId).orElseThrow(() -> new RuntimeException("Admin not found"));

        Conversation conversation = new Conversation();
        conversation.setCandidat(candidat);
        conversation.setAdmin(admin);

        return conversationRepository.save(conversation);
    }

    // Envoie un message dans une conversation
    public Message sendMessage(Long conversationId, String sender, String content) {
        Conversation conversation = conversationRepository.findById(conversationId).orElseThrow(() -> new RuntimeException("Conversation not found"));

        // Check if the sender is valid (either Candidat or Admin)
        if (!sender.equals("Candidat") && !sender.equals("Admin")) {
            throw new IllegalArgumentException("Invalid sender");
        }

        Message message = new Message();
        message.setConversation(conversation);
        message.setSender(sender);
        message.setContent(content);
        message.setTimestamp(LocalDateTime.now());

        return messageRepository.save(message);
    }

    // Récupère tous les messages d'une conversation
    public List<Message> getMessagesByConversationId(Long conversationId) {
        return messageRepository.findByConversationId(conversationId);
    }
}
