package com.example.youssefsaibi.Service;



import com.example.youssefsaibi.Entity.Recruteur;
import com.example.youssefsaibi.Repository.RecruteurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RecruteurService {

    @Autowired
    private RecruteurRepository recruteurRepository;

    public List<Recruteur> getAllRecruteurs() {
        return recruteurRepository.findAll();
    }

    public Optional<Recruteur> getRecruteurById(Long id) {
        return recruteurRepository.findById(id);
    }

    public Recruteur addRecruteur(Recruteur recruteur) {
        return recruteurRepository.save(recruteur);
    }

    public Recruteur updateRecruteur(Long id, Recruteur updatedRecruteur) {
        return recruteurRepository.findById(id).map(recruteur -> {
            recruteur.setNom(updatedRecruteur.getNom());
            recruteur.setEmail(updatedRecruteur.getEmail());
            recruteur.setEntreprise(updatedRecruteur.getEntreprise());
            return recruteurRepository.save(recruteur);
        }).orElseThrow(() -> new RuntimeException("Recruteur introuvable"));
    }

    public void deleteRecruteur(Long id) {
        recruteurRepository.deleteById(id);
    }
}
