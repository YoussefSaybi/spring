package com.example.youssefsaibi.Controller;



import com.example.youssefsaibi.Entity.Recruteur;
import com.example.youssefsaibi.Service.RecruteurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

        import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/recruteurs")
public class RecruteurController {

    @Autowired
    private RecruteurService recruteurService;

    @GetMapping
    public List<Recruteur> getAllRecruteurs() {
        return recruteurService.getAllRecruteurs();
    }

    @GetMapping("/{id}")
    public Optional<Recruteur> getRecruteurById(@PathVariable Long id) {
        return recruteurService.getRecruteurById(id);
    }

    @PostMapping
    public Recruteur addRecruteur(@RequestBody Recruteur recruteur) {
        return recruteurService.addRecruteur(recruteur);
    }

    @PutMapping("/{id}")
    public Recruteur updateRecruteur(@PathVariable Long id, @RequestBody Recruteur updatedRecruteur) {
        return recruteurService.updateRecruteur(id, updatedRecruteur);
    }

    @DeleteMapping("/{id}")
    public void deleteRecruteur(@PathVariable Long id) {
        recruteurService.deleteRecruteur(id);
    }
}
