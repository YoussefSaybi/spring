package com.example.youssefsaibi.Controller;

import com.example.youssefsaibi.Entity.Conversation;
import com.example.youssefsaibi.Entity.Message;
import com.example.youssefsaibi.Service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageService messageService;

    // Envoie un message dans une conversation
    @PostMapping("/send")
    public Message sendMessage(@RequestParam Long conversationId, @RequestParam String sender, @RequestParam String content) {
        return messageService.sendMessage(conversationId, sender, content);
    }

    // Récupère tous les messages d'une conversation
    @GetMapping("/conversation/{id}")
    public List<Message> getMessagesByConversationId(@PathVariable Long id) {
        return messageService.getMessagesByConversationId(id);
    }

    // Créer une nouvelle conversation
    @PostMapping("/create")
    public Conversation createConversation(@RequestParam Long candidatId, @RequestParam Long adminId) {
        return messageService.createConversation(candidatId, adminId);
    }
}
