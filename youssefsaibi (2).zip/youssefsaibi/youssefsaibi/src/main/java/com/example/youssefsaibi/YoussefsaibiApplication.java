package com.example.youssefsaibi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoussefsaibiApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoussefsaibiApplication.class, args);
	}

}
