package com.example.youssefsaibi.Repository;

import com.example.youssefsaibi.Entity.Candidat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidatRepository extends JpaRepository<Candidat, Long> {
}
