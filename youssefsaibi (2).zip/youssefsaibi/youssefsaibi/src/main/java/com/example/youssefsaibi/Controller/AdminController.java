package com.example.youssefsaibi.Controller;

import com.example.youssefsaibi.Entity.Admin;
import com.example.youssefsaibi.Service.AdminService;
import com.example.youssefsaibi.Service.MessagingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private MessagingService messagingService;

    @GetMapping
    public List<Admin> getAllAdmins() {
        return adminService.getAllAdmins();
    }

    @GetMapping("/{id}")
    public Optional<Admin> getAdminById(@PathVariable Long id) {
        return adminService.getAdminById(id);
    }

    @PostMapping
    public Admin addAdmin(@RequestBody Admin admin) {
        Admin savedAdmin = adminService.addAdmin(admin);
        messagingService.sendMessage("Admin créé : " + savedAdmin.getName()); // Simulate sending a message
        return savedAdmin;
    }

    @PutMapping("/{id}")
    public Admin updateAdmin(@PathVariable Long id, @RequestBody Admin updatedAdmin) {
        Admin updated = adminService.updateAdmin(id, updatedAdmin);
        messagingService.sendMessage("Admin mis à jour : " + updated.getName()); // Simulate sending a message
        return updated;
    }

    @DeleteMapping("/{id}")
    public void deleteAdmin(@PathVariable Long id) {
        adminService.deleteAdmin(id);
        messagingService.sendMessage("Admin supprimé : " + id); // Simulate sending a message
    }
}
