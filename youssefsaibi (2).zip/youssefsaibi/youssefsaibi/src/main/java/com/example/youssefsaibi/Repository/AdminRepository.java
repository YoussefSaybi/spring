package com.example.youssefsaibi.Repository;



import com.example.youssefsaibi.Entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, Long> {
}
