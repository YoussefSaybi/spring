//package com.example.youssefsaibi.Messaging;
//
//import com.example.youssefsaibi.Entity.Candidat;
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//import org.springframework.stereotype.Component;
//
//@Component
//public class CandidatListener {
//
//    @RabbitListener(queues = "candidatQueue")
//    public void receiveMessage(Candidat candidat) {
//        // Handle the incoming Candidat message
//        System.out.println("Received Candidat: " + candidat);
//        // You could process or save the candidate data to the database here.
//    }
//}
