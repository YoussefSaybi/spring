package com.example.youssefsaibi.Service;


import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GeoLocationService {

    private final String apiKey = "3192f0fb3385451c81fa761bd87ee26e";

    public String getLocationByCoordinates(double latitude, double longitude) {
        String url = String.format("https://api.opencagedata.com/geocode/v1/json?q=%f,%f&key=%s", latitude, longitude, apiKey);

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(url, String.class);

        return response; // you can process this response to extract the address
    }
}
