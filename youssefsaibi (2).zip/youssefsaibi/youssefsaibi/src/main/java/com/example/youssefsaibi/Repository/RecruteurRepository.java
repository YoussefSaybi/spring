package com.example.youssefsaibi.Repository;

import com.example.youssefsaibi.Entity.Recruteur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecruteurRepository extends JpaRepository<Recruteur, Long> {
}
